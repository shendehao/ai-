# 🔑 API配置说明

## ⚠️ 重要提醒

你的合同分析功能出现了两个配置问题需要解决：

### 1. 🚨 **DashScope API Key 未配置**

**错误信息**：`Incorrect API key provided`

**问题**：`.env` 文件中的 `DASHSCOPE_API_KEY` 还是默认值

**解决方案**：
```bash
# 编辑 .env 文件
DASHSCOPE_API_KEY=sk-your-real-api-key-here
```

**获取API Key步骤**：
1. 访问 [阿里云模型服务灵积](https://dashscope.aliyun.com/)
2. 登录/注册阿里云账号
3. 开通DashScope服务
4. 获取API Key（格式：`sk-xxxxxxxxxxxxxx`）
5. 替换 `.env` 文件中的默认值

### 2. ✅ **OCR问题已修复**

**问题**：`a bytes-like object is required, not 'str'`

**解决方案**：已修复云端OCR函数，现在支持：
- ✅ 字节内容输入（bytes）
- ✅ 文件路径输入（str）
- ✅ 自动类型检测和处理

---

## 🔧 完整配置步骤

### 1️⃣ **配置DashScope API**

```bash
# .env 文件配置
DASHSCOPE_API_KEY=sk-your-real-dashscope-api-key

# 百度OCR配置（可选，用于图片识别）
BAIDU_OCR_API_KEY=your-baidu-api-key
BAIDU_OCR_SECRET_KEY=your-baidu-secret-key
```

### 2️⃣ **测试配置**

启动服务后访问：
- 简历分析器：`http://localhost:8000/`
- 合同分析器：`http://localhost:8000/contract`

### 3️⃣ **功能验证**

**合同分析器支持**：
- 📄 PDF格式合同
- 🖼️ 图片格式合同（需要OCR）
- 📝 文本格式合同
- 🔍 AI智能分析和风险识别

---

## 🎯 API Key获取指南

### **DashScope API Key**

1. **访问官网**：https://dashscope.aliyun.com/
2. **注册登录**：使用阿里云账号
3. **开通服务**：
   - 选择"通义千问"模型
   - 开通API调用服务
   - 获取免费额度或购买套餐
4. **获取密钥**：
   - 进入控制台
   - 找到"API-KEY管理"
   - 创建新的API Key
   - 复制密钥（格式：sk-xxxxxxxxx）

### **百度OCR API Key（可选）**

1. **访问官网**：https://cloud.baidu.com/product/ocr
2. **注册登录**：百度智能云账号
3. **创建应用**：
   - 选择"文字识别OCR"
   - 创建应用获取API Key和Secret Key
4. **获取密钥**：
   - API Key：用于身份验证
   - Secret Key：用于签名验证

---

## 🚀 启动服务

配置完成后：

```bash
# 启动服务
python main.py

# 访问应用
# 简历分析：http://localhost:8000/
# 合同分析：http://localhost:8000/contract
```

---

## 🔍 故障排除

### **常见错误**

1. **API Key无效**
   ```
   Error code: 401 - invalid_api_key
   ```
   **解决**：检查API Key是否正确，是否有sk-前缀

2. **OCR服务不可用**
   ```
   OCR text extraction failed
   ```
   **解决**：配置百度OCR或使用PDF格式文件

3. **服务配置错误**
   ```
   AI服务配置错误
   ```
   **解决**：确保.env文件中的API Key已正确配置

### **验证配置**

```bash
# 检查环境变量
echo $DASHSCOPE_API_KEY

# 检查服务状态
curl http://localhost:8000/health
curl http://localhost:8000/ocr-status
```

---

## 💡 使用建议

1. **推荐格式**：PDF > 图片 > 文本
2. **文件大小**：建议10MB以内
3. **图片质量**：清晰、正向、高对比度
4. **网络环境**：确保能访问阿里云API服务

配置完成后，你的合同分析器就能正常工作了！🎉
